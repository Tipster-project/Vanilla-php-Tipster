	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	
	<script src="js/main.js"></script>
	<script src="bootstrap/js/bootstrap.min.js"></script>

</body>
</html>